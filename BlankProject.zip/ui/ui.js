export default class UI {

  render(context) {

  }
}