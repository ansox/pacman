import Entity from './entity.js';
import World from '../world/world.js';

export default class Player extends Entity {
  right = false;
  left = false;
  up = false;
  down = false;


  constructor(x, y, width, height, speed, sprite) {
    super(x, y, width, height, speed, sprite);
  }

  tick() {
    if (this.right && World.isFree(this.x + this.speed, this.y)) {
      this.x += this.speed;
    } else if (this.left && World.isFree(this.x - this.speed, this.y)) {
      this.dir = this.leftDir;
    } else if (this.up && World.isFree(this.x, this.y - this.speed)) {
      this.y -= this.speed;
    } else if (this.down && World.isFree(this.x, this.y + this.speed)) {
      this.y += this.speed;
    }
  }

  render(context) {

  }
}