import Game from './game.js'

let game = new Game();

game.start();