export default class Tile {
  tileFloor;
  tileWall;

  sprite;
  x = 0
  y = 0;

  constructor(x, y, sprite) {
    this.x = x;
    this.y = y;
    this.sprite = sprite;
  }

  render(context) {

  }

}